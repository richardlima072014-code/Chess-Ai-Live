package com.chessailive.app

import android.os.Bundle
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

private val Navy = Color(0xFF0A1020)
private val Panel = Color(0xFF151F33)
private val Cyan = Color(0xFF35D6E8)
private val LightSquare = Color(0xFFE7DCC8)
private val DarkSquare = Color(0xFF71869A)

class MainActivity : ComponentActivity() {
    private var tts: TextToSpeech? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) tts?.language = Locale("pt", "BR")
        }
        setContent { ChessLiveApp { speak(it) } }
    }

    private fun speak(message: String) {
        tts?.speak(message, TextToSpeech.QUEUE_FLUSH, null, "chess_tip")
    }

    override fun onDestroy() {
        tts?.shutdown()
        super.onDestroy()
    }
}

@Composable
fun ChessLiveApp(onSpeak: (String) -> Unit) {
    var selected by remember { mutableStateOf<Int?>(null) }
    var message by remember {
        mutableStateOf("Bem-vindo! Use este espaço para estudar posições e aprender princípios de xadrez.")
    }
    val pieces = remember {
        mutableStateListOf(
            "♜","♞","♝","♛","♚","♝","♞","♜",
            "♟","♟","♟","♟","♟","♟","♟","♟",
            "","","","","","","","",
            "","","","","","","","",
            "","","","","","","","",
            "","","","","","","","",
            "♙","♙","♙","♙","♙","♙","♙","♙",
            "♖","♘","♗","♕","♔","♗","♘","♖"
        )
    }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Navy, surface = Panel, primary = Cyan,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Column(
            Modifier.fillMaxSize().background(Navy).padding(18.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("CHESS AI LIVE", color = Cyan, fontSize = 25.sp, fontWeight = FontWeight.Black)
            Text("SEU TREINADOR DE XADREZ", color = Color.LightGray, fontSize = 11.sp)
            Spacer(Modifier.height(18.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("♟  MODO TREINO", color = Color.White, fontWeight = FontWeight.Bold)
                Text("v0.1", color = Cyan)
            }
            Spacer(Modifier.height(12.dp))
            Column(Modifier.fillMaxWidth().aspectRatio(1f)) {
                for (r in 0..7) {
                    Row(Modifier.weight(1f)) {
                        for (c in 0..7) {
                            val idx = r * 8 + c
                            val isSelected = selected == idx
                            Box(
                                Modifier.weight(1f).fillMaxHeight()
                                    .background(if ((r + c) % 2 == 0) LightSquare else DarkSquare)
                                    .clickable {
                                        selected = if (selected == idx) null else idx
                                        message = "Casa ${'a' + c}${8-r} selecionada. Esta versão inicial é um protótipo de treino."
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                if (pieces[idx].isNotEmpty()) {
                                    Text(pieces[idx], fontSize = 29.sp, color = Color.Black)
                                }
                                if (isSelected) {
                                    Box(Modifier.fillMaxSize().background(Cyan.copy(alpha = 0.35f)))
                                }
                            }
                        }
                    }
                }
            }
            Spacer(Modifier.height(16.dp))
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(14.dp)) {
                    Text("ASSISTENTE", color = Cyan, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    Text(message, color = Color.White, fontSize = 14.sp)
                }
            }
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = {
                        message = "Dica: controle o centro com peões e desenvolva cavalos e bispos antes de atacar."
                        onSpeak(message)
                    },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = Cyan, contentColor = Navy)
                ) { Text("DICA POR VOZ") }
                OutlinedButton(
                    onClick = {
                        selected = null
                        message = "Tabuleiro reiniciado. Esta versão ainda não calcula variantes com Stockfish."
                    },
                    modifier = Modifier.weight(1f)
                ) { Text("REINICIAR") }
            }
            Spacer(Modifier.height(10.dp))
            Text(
                "Protótipo de estudo. Análise Stockfish e compartilhamento de tela serão adicionados nas próximas etapas.",
                color = Color.LightGray, fontSize = 11.sp
            )
        }
    }
}
