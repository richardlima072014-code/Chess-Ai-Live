# Chess AI Live — protótipo Android

Este é o projeto-fonte inicial de um aplicativo Android em Kotlin + Jetpack Compose.

## O que já funciona
- Interface escura Chess AI Live.
- Tabuleiro visual inicial.
- Seleção de casas.
- Dica de fundamentos do xadrez lida em voz alta pelo Android (Text-to-Speech).

## Ainda não implementado
- Motor Stockfish integrado.
- Reconhecimento automático do tabuleiro por câmera/tela.
- Compartilhamento de tela via MediaProjection.
- Conversa com IA online.

Esses recursos exigem integração e testes adicionais. O protótipo não fornece assistência durante partidas competitivas online.

## Como gerar o APK
1. Instale Android Studio em um computador.
2. Abra a pasta `ChessAILive` no Android Studio.
3. Aguarde a sincronização do Gradle.
4. Selecione **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. O Android Studio mostrará o caminho do APK gerado.

Requisitos: Android Studio recente, JDK 17 e conexão à internet na primeira sincronização.
